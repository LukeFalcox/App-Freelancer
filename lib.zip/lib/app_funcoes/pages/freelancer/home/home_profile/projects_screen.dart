import 'package:app_freelancer/app_funcoes/pages/configs/auth_service.dart';
import 'package:flutter/material.dart'; // Importa o pacote principal do Flutter
import 'package:intl/intl.dart'; // Importa a biblioteca Intl para manipulação de datas
import 'project_detail_screen.dart'; // Importa a tela de detalhes do projeto
import 'package:flutter/material.dart';


class ProjectsScreen extends StatefulWidget {
  final AuthService authService;
  final bool freeorcli;
  final String useremail;

  const ProjectsScreen({
    super.key,
    required this.authService,
    required this.freeorcli,
    required this.useremail,
  });

  @override
  _ProjectsScreenState createState() => _ProjectsScreenState();
}

class _ProjectsScreenState extends State<ProjectsScreen> {
  String? usercliorfree;
  String? area;

  @override
  void initState() {
    super.initState();
    _fetchArea();
  }

  Future<void> _fetchArea() async {
    area = await widget.authService.getArea(widget.useremail);
    setState(() {});
  }

  DateTime _parseDate(String date) {
    return DateFormat('yyyy-MM-dd').parse(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("meus projetos"),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
          ),
          Expanded(
            child: area == null
                ? const Center(child: CircularProgressIndicator())
                : FutureBuilder(
                    future: widget.authService.getProjects(widget.useremail),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      } else if (snapshot.hasError) {
                        return Center(child: Text('Error: ${snapshot.error}'));
                      } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                        return const Center(child: Text('Nenhum freelancer encontrado.'));
                      } else {
                        List<dynamic> cards = snapshot.data!;
                        return ListView.builder(
                          itemCount: cards.length,
                          itemBuilder: (context, index) {
                            var project = cards[index];
                            return GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ProjectDetailScreen(
                                      authService: widget.authService,
                                      freeorcli: widget.freeorcli,
                                      usercliorfree: usercliorfree!,
                                      useremail: widget.useremail,
                                    ),
                                  ),
                                );
                              },
                              child: Container(
                                margin: const EdgeInsets.only(bottom: 16),
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.1),
                                      blurRadius: 6,
                                      spreadRadius: 2,
                                      offset: const Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: Text(
                                            project['titulo'],
                                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            showDialog(
                                              context: context,
                                              builder: (context) {
                                                return AlertDialog(
                                                  title: const Text("Significado do Status"),
                                                  content: Text(
                                                    project['status'] == 'em andamento'
                                                        ? "O projeto está em Andamento"
                                                        : "O projeto foi Ativo",
                                                  ),
                                                  actions: [
                                                    TextButton(
                                                      onPressed: () {
                                                        Navigator.of(context).pop();
                                                      },
                                                      child: const Text("Fechar"),
                                                    ),
                                                  ],
                                                );
                                              },
                                            );
                                          },
                                          child: Container(
                                            width: 20,
                                            height: 20,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: project['status'] == 'em andamento' ? Colors.orange : Colors.green,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Descrição: ${project["desc"].toLowerCase()}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(color: Colors.grey),
                                    ),
                                    const SizedBox(height: 4),
                                    ProjectWidget(project: project),
                                    const SizedBox(height: 8),
                                    // Botão "PAGAR" se o status for "finalizado"
                                    if (project['status'] == 'finalizado')
                                      Align(
                                        alignment: Alignment.bottomRight,
                                        child: ElevatedButton(
                                          onPressed: () {
                                            // Adicione a lógica do botão "PAGAR" aqui
                                            print('Botão PAGAR pressionado para o projeto: ${project['titulo']}');
                                          },
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.blue, // Cor de fundo do botão
                                          ),
                                          child: const Text("PAGAR"),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      }
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

// Exemplo de widget onde a data é exibida
class ProjectWidget extends StatelessWidget {
  final Map<String, dynamic> project;

  ProjectWidget({required this.project});

  @override
  Widget build(BuildContext context) {
    // Converte a string para DateTime
    DateTime dateTime = DateTime.parse(project['dtfim']);

    // Formata a data no formato desejado
    String formattedDate = DateFormat('dd/MM/yyyy').format(dateTime);

    return Text(
      "Fim: $formattedDate",
      style: const TextStyle(color: Colors.grey),
    );
  }
}
