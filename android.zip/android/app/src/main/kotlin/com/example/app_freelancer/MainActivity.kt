package com.example.app_freelancer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
